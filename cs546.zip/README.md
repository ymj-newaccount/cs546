# CommuteAble NYC (CS546)

An accessibility-focused NYC transit companion. This project ingests multiple NYC/MTA open-data datasets into MongoDB and provides:

- An **Explore** page with a Leaflet map + filters (Stations / Accessible Stations / Elevators / APS / Curb Ramps) and a list-view alternative.
- **Community Reports**: logged-in users can submit obstacle reports directly from map popups (**AJAX**, CSRF-protected).
- **Follow/Unfollow Stations**: logged-in users can bookmark stations from station popups (**AJAX**, CSRF-protected).
- A **User Dashboard** (`/dashboard`) showing followed stations and the user’s submitted reports.
- An **Admin** dashboard for **data sync (seedAll)** and **report moderation** (Hide / Unhide / Delete).
- **Auth** (Register / Login / Logout) with sessions and CSRF protection.

---

## Tech Stack

- **Node.js** (ESM) — Node **>= 20** recommended
- **Express**
- **MongoDB**
- **express-handlebars** (Handlebars templates)
- **Leaflet** (map rendering)
- **express-session** (login sessions)
- **bcryptjs** (password hashing)

---

## Datasets (Open Data)

The seed script downloads and imports 4 public CSV datasets:

- MTA Subway Stations (metadata + ADA + routes)  
  https://data.ny.gov/api/views/39hk-dx4f/rows.csv?accessType=DOWNLOAD
- MTA Elevator & Escalator Availability (monthly availability)  
  https://data.ny.gov/api/views/rc78-7x78/rows.csv?accessType=DOWNLOAD
- NYC DOT Accessible Pedestrian Signals (APS)  
  https://data.cityofnewyork.us/api/views/de3m-c5p4/rows.csv?accessType=DOWNLOAD
- NYC Curb Ramp Locations  
  https://data.cityofnewyork.us/api/views/ufzp-rrqu/rows.csv?accessType=DOWNLOAD

> Note on **Elevators**: The availability dataset does not provide reliable point coordinates per equipment. We approximate elevator point locations by joining the elevator row to a station and using that station’s coordinates (via **Station MRN → Station ID**).

---

## Prerequisites

- Node.js **>= 20**
- MongoDB running locally (or a reachable Mongo connection string)
- npm

---

## Setup

### 1) Install dependencies

```bash
npm install
```

### 2) Create `.env`

Create a `.env` file in the project root:

```env
MONGO_URL=mongodb://127.0.0.1:27017
MONGO_DB_NAME=CommuteAbleNYC
SESSION_SECRET=change-me-to-a-long-random-string
```

Optional (only if your `routes/admin.js` supports Basic Auth fallback):

```env
ADMIN_USER=admin
ADMIN_PASS=change-me-too
```

### 3) Seed the database (required)

```bash
npm run seed
```

Optional: seed sample reports so the Admin moderation table has content:

```bash
node tasks/seedSampleReports.js
```

### 4) Start the server

```bash
npm start
```

or dev mode (if configured):

```bash
npm run dev
```

Open:

- http://localhost:3000/explore

---

## Usage Guide

### Register / Login

- Register: `GET /register`
- Login: `GET /login`
- Logout: `POST /logout` (via UI button/form)

**Role bootstrap**: the **first** user created in an empty DB becomes `admin`. Later users default to `user`.

### Explore (Map + Filters)

- `GET /explore`
- Filters load data from `GET /explore/api` and update the map via AJAX:
  - Stations
  - Accessible Stations
  - Elevators
  - APS
  - Curb Ramps

### Community Reports (User Submission)

When logged in, each marker popup includes a **Report obstacle** button.
Submitting a report sends an AJAX request to:

- `POST /api/reports` (requires login, CSRF-protected)

Reports created by users appear in the Admin moderation table (`/admin`) for Hide/Unhide/Delete.

### Follow / Unfollow Stations

When logged in, station popups include a **Follow station** / **Unfollow station** toggle.
This sends an AJAX request to:

- `POST /api/stations/:stationId/follow`
- `POST /api/stations/:stationId/unfollow`

Followed stations are stored in the user’s `bookmarks` array and displayed on `/dashboard`.

### Dashboard

- `GET /dashboard` (requires login)
- Shows:
  - Followed stations (bookmarks)
  - The user’s submitted reports

### Admin Dashboard

- `GET /admin`
- Requires an authenticated admin session (or Basic Auth fallback if enabled).
- Features:
  - **Sync Data**: runs `seedAll()` and refreshes stations/elevators/APS/ramps
  - **Moderate Reports**:
    - Hide (status → `hidden`)
    - Unhide (status → `open`)
    - Delete (remove document)

All mutating admin actions are protected by CSRF tokens.

---

## Scripts

Common scripts (depending on your `package.json`):

```bash
npm start          # Start server
npm run dev        # Start server with nodemon (if configured)
npm run seed       # Run tasks/seed.js (imports open datasets)
```

Sanity-check / test scripts:

```bash
node tasks/testStations.js
node tasks/testElevators.js
node tasks/testLocations.js
node tasks/seedSampleReports.js
```

---

## Project Structure (Key Files)

- `app.js` — Express app bootstrap, middleware, session, error handling, shutdown
- `config/routes.js` — route registration
- `routes/`
  - `explore.js` — Explore page + GeoJSON API
  - `reports.js` — Community report submission API (`/api/reports`)
  - `stationsApi.js` — Follow/unfollow stations API (`/api/stations/...`)
  - `dashboard.js` — User dashboard (`/dashboard`)
  - `admin.js` — Admin dashboard + moderation + sync
  - `auth.js` — Register/Login/Logout + CSRF helpers
- `data/`
  - `stations.js`, `elevators.js`, `locations.js`
  - `reports.js` — Report create/query helpers (user-facing)
  - `reportsAdmin.js` — Admin-facing report moderation helpers (if present)
  - `users.js` — Users + bookmarks + alerts
- `tasks/`
  - `seed.js` — downloads and imports the 4 datasets
  - `seedSampleReports.js` — inserts demo reports
  - `testStations.js`, `testElevators.js`, `testLocations.js`
- `views/`
  - `layouts/main.handlebars`
  - `explore.handlebars`, `admin.handlebars`, `dashboard.handlebars`
  - `register.handlebars`, `login.handlebars`
- `public/`
  - `js/explore.js` — client-side map + list refresh + report submit + follow/unfollow
  - `js/theme.js` — theme toggle
  - `css/main.css`

---

## Troubleshooting

### 1) “Elevators = 0” on Explore

- Re-run seed:
  ```bash
  npm run seed
  ```
- Confirm elevators have coordinates in Mongo:
  ```js
  db.elevators.countDocuments({ "location.lat": { $ne: null }, "location.lng": { $ne: null } })
  ```
- If it’s still 0, check your elevator join keys:
  - Elevator dataset uses **Station MRN** (`station_mrn`)
  - Stations dataset uses **Station ID** as MRN

### 2) 403 Forbidden (CSRF)

This project uses CSRF protection for both form POSTs and AJAX POSTs.

- For **form POSTs** (register/login/logout/admin actions), ensure the form includes:
  - `<input type="hidden" name="csrfToken" value="{{csrfToken}}">`

- For **AJAX POSTs** (`/api/reports`, `/api/stations/...`), ensure:
  - the page includes `<meta name="csrf-token" content="{{csrfToken}}">`
  - the client sends header: `x-csrf-token: <token from meta>`

### 3) Cannot access `/admin` in incognito

Expected. `/admin` is protected.

- Log in as an **admin** user (first registered user on a fresh DB is admin), or
- If Basic Auth fallback is enabled, provide `ADMIN_USER/ADMIN_PASS`.

### 4) Node version errors

Use Node >= 20. If your project has `scripts/checkNode.js`, it will block older versions.

---

## Security Notes (Coursework Scope)

- Passwords are hashed with bcrypt (`bcryptjs`).
- Sessions via `express-session`.
- Mutating requests are protected with double-submit cookie CSRF tokens.
- Admin routes are protected via session role checks (and optionally Basic Auth fallback, depending on your version).

---

## License / Attribution

This is a coursework project. Data sources are public NYC/MTA open datasets listed above.
